homeDir="/Users/huqiaonan/Documents/shTest/allTest/"
#{
#sh ${homeDir}pushDiLian.sh
#}&
#{
#sh ${homeDir}pushXunLei.sh
#}&
{
sh ${homeDir}pushLeShi.sh
}&
{
sh ${homeDir}pushWangSu.sh
}&
wait
