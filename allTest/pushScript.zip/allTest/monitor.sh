
while test "1"="1"
do
ps -ax | grep allTest | wc
ps -ax | grep allTest
echo `date`
sleep 30

# /home/nvenc/Downloads/ffmpeg-2.8.1-64bit-static/ffmpeg -re -i $1 -codec copy -f flv $2;
done
